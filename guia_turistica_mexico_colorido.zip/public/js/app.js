fetch("/api/lugares")
  .then(r => r.json())
  .then(lugares => {
    const c = document.getElementById("lista-lugares");
    lugares.forEach(l => {
      c.innerHTML += `
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="${l.imagen}" class="card-img-top" style="height:200px; object-fit:cover;">
            <div class="card-body">
              <h5 class="card-title">${l.nombre}</h5>
              <p class="card-text text-truncate">${l.descripcion}</p>
              <a href="lugar.html?id=${l._id}" class="btn btn-sm btn-warning">Ver ficha</a>
            </div>
          </div>
        </div>`;
    });
  });
