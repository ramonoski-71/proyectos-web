import express from "express";
import conexion from "../db/conexion.js";

const router = express.Router();

// Obtener todos los casos
router.get("/", (req, res) => {
  conexion.query("SELECT * FROM casos ORDER BY id DESC", (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Obtener un caso por id
router.get("/:id", (req, res) => {
  const { id } = req.params;
  conexion.query("SELECT * FROM casos WHERE id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ error: "Caso no encontrado" });
    res.json(results[0]);
  });
});

// Crear un caso
router.post("/", (req, res) => {
  const { cliente, descripcion, estatus } = req.body;
  conexion.query(
    "INSERT INTO casos (cliente, descripcion, estatus) VALUES (?, ?, ?)",
    [cliente, descripcion, estatus || "En proceso"],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Caso registrado", id: results.insertId });
    }
  );
});

// Actualizar un caso
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { cliente, descripcion, estatus } = req.body;
  conexion.query(
    "UPDATE casos SET cliente = ?, descripcion = ?, estatus = ? WHERE id = ?",
    [cliente, descripcion, estatus, id],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Caso actualizado" });
    }
  );
});

// Eliminar un caso
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  conexion.query("DELETE FROM casos WHERE id = ?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Caso eliminado" });
  });
});

export default router;
