const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/guiaturistica");
const LugarSchema = new mongoose.Schema({
  nombre: String,
  descripcion: String,
  ubicacion: String,
  categoria: String,
  imagen: String,
  horario: String
});
const Lugar = mongoose.model("Lugar", LugarSchema);

async function seed() {
  await Lugar.deleteMany({});
  await Lugar.insertMany([
    {
      nombre: "Dos Aguas",
      descripcion: "Un hermoso paraje rodeado de bosques, ideal para desconectarte y disfrutar de la naturaleza.",
      ubicacion: "Dos Aguas, México",
      categoria: "Naturaleza",
      imagen: "/img/dosaguas.jpg",
      horario: "Abierto todo el día"
    },
    {
      nombre: "Teotihuacán",
      descripcion: "Zona arqueológica con las famosas Pirámides del Sol y la Luna.",
      ubicacion: "Teotihuacán, Estado de México",
      categoria: "Histórico",
      imagen: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Teotihuacan_sun_pyramid.jpg/800px-Teotihuacan_sun_pyramid.jpg",
      horario: "8:00 - 17:00"
    },
    {
      nombre: "Bacalar",
      descripcion: "La Laguna de los Siete Colores, un paraíso en el sureste mexicano.",
      ubicacion: "Bacalar, Quintana Roo",
      categoria: "Playa",
      imagen: "https://mexicodesconocido.com.mx/wp-content/uploads/2022/04/bacalar-laguna-7-colores.jpg",
      horario: "Variable"
    }
  ]);
  console.log("Seed completado");
  process.exit();
}

seed();
