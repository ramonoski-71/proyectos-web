const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const session = require("express-session");

const app = express();
app.use(express.json());
app.use(session({
  secret: "ramon-secret-123",
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60*60*1000 }
}));

// MongoDB connection
mongoose.connect("mongodb://localhost:27017/guiaturistica")
  .then(()=> console.log("✅ MongoDB conectado"))
  .catch(err => console.error("❌ Error MongoDB:", err));

const LugarSchema = new mongoose.Schema({
  nombre: String,
  descripcion: String,
  ubicacion: String,
  categoria: String,
  imagen: String,
  horario: String
});
const Lugar = mongoose.model("Lugar", LugarSchema);

// Auth middleware
function requireAuth(req, res, next) {
  if (req.session && req.session.user === "admin") return next();
  return res.redirect("/login.html");
}

// Login endpoint
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "admin") {
    req.session.user = "admin";
    return res.json({ ok: true });
  }
  return res.status(401).json({ ok: false, message: "Credenciales inválidas" });
});

app.post("/logout", (req, res) => {
  req.session.destroy(()=> res.json({ ok: true }));
});

// API endpoints
app.get("/api/lugares", async (req, res) => {
  const lugares = await Lugar.find();
  res.json(lugares);
});

app.get("/api/lugares/:id", async (req, res) => {
  const lugar = await Lugar.findById(req.params.id);
  if (!lugar) return res.status(404).json({ error: "No encontrado" });
  res.json(lugar);
});

app.post("/api/lugares", requireAuth, async (req, res) => {
  const nuevo = new Lugar(req.body);
  await nuevo.save();
  res.json({ mensaje: "Lugar agregado" });
});

// Serve protected admin page via route so we can check session
app.get("/agregar.html", requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "agregar.html"));
});

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

// Start server
const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log("Servidor en http://localhost:" + port));
