import mysql from "mysql2";
import dotenv from "dotenv";
dotenv.config();

const conexion = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "",
  database: process.env.DB_NAME || "despacho",
  port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306
});

conexion.connect((err) => {
  if (err) {
    console.error("❌ Error de conexión:", err);
    return;
  }
  console.log("✅ Conectado a la base de datos");
});

export default conexion;
