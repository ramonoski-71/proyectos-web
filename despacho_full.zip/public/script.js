const tabla = document.getElementById("tablaCasos");
const form = document.getElementById("formCaso");
const clienteEl = document.getElementById("cliente");
const descripcionEl = document.getElementById("descripcion");
const estatusEl = document.getElementById("estatus");
const casoIdEl = document.getElementById("casoId");
const cancelEditBtn = document.getElementById("cancelEdit");

async function cargarCasos() {
  const res = await fetch("/api/casos");
  const datos = await res.json();
  tabla.innerHTML = "";
  datos.forEach(caso => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${caso.id}</td>
      <td>${caso.cliente}</td>
      <td>${caso.descripcion}</td>
      <td>${caso.estatus}</td>
      <td>
        <button data-id="${caso.id}" class="edit">Editar</button>
        <button data-id="${caso.id}" class="del">Eliminar</button>
      </td>
    `;
    tabla.appendChild(tr);
  });

  document.querySelectorAll(".del").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      const id = e.target.dataset.id;
      if (!confirm("¿Eliminar este caso?")) return;
      await fetch(`/api/casos/${id}`, { method: "DELETE" });
      cargarCasos();
    });
  });

  document.querySelectorAll(".edit").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      const id = e.target.dataset.id;
      const res = await fetch(`/api/casos/${id}`);
      const caso = await res.json();
      casoIdEl.value = caso.id;
      clienteEl.value = caso.cliente;
      descripcionEl.value = caso.descripcion;
      estatusEl.value = caso.estatus;
      cancelEditBtn.style.display = "inline-block";
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    cliente: clienteEl.value.trim(),
    descripcion: descripcionEl.value.trim(),
    estatus: estatusEl.value.trim() || "En proceso"
  };

  if (casoIdEl.value) {
    // editar
    await fetch(`/api/casos/${casoIdEl.value}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    casoIdEl.value = "";
    cancelEditBtn.style.display = "none";
  } else {
    // crear
    await fetch("/api/casos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  form.reset();
  cargarCasos();
});

cancelEditBtn.addEventListener("click", () => {
  casoIdEl.value = "";
  form.reset();
  cancelEditBtn.style.display = "none";
});

// cargar al inicio
cargarCasos();
